#include <nlohmann/json.hpp>
#include "Foo.hpp"

class Bar : public Foo{};
